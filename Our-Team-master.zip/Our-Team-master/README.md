    This is a modal designed with html and css only. Frontend Framework Bootstrap 4.1.3 is used.
    Fully responsive template for your "our team" section.
    Images used in this are not licensed for public use,
    you can replace the image to use the code in your project.

Step 1: Paste team-wrapper section from index page to your required section.
Step 2: Copy entire style sheet code and paste it in your style sheet at any place.
Hope this template helps you in your project.

Demo: https://condescending-carson-082be9.netlify.com/

    Developed By:       Bishwo Raj Raut

    Contact:
    Facebook:           https://www.facebook.com/bishow.raut.7
    Linkedin:           https://www.linkedin.com/in/bishwo-raut-53371b186
    GitHub:             https://github.com/brraut
    Instagram:          https://www.instagram.com/brraut/
